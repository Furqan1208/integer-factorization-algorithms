import math
import random
from utils import gcd

def trial_division(n):
    """
    Factorizes an integer n using the Trial Division method.
    Returns a list of factors.
    """
    if n <= 1:
        return []
    factors = []
    while n % 2 == 0:
        factors.append(2)
        n //= 2
    for i in range(3, int(math.sqrt(n)) + 1, 2):
        while n % i == 0:
            factors.append(i)
            n //= i
    if n > 2:
        factors.append(n)
    return factors

def pollards_rho(n):
    """
    Factorizes an integer n using Pollard's Rho algorithm.
    Returns a list of factors if any are found.
    """
    if n <= 1:
        return []
    if n % 2 == 0:
        return [2]

    x = random.randint(2, n - 1)
    y = x
    c = random.randint(1, n - 1)
    d = 1

    while d == 1:
        x = (x * x + c) % n
        y = (y * y + c) % n
        y = (y * y + c) % n
        d = gcd(abs(x - y), n)
        if d == n:
            return pollards_rho(n)
    return [d] if d != n else []

def rsa_decrypt_with_pollards_rho(n, e, c):
    """
    Solve the RSA problem using Pollard's Rho to factorize n.
    Inputs:
        n: The modulus (product of primes p and q).
        e: The public key exponent.
        c: The ciphertext to decrypt.
    Outputs:
        m: The decrypted message.
    """
    # Step 1: Factorize n using Pollard's Rho
    factors = pollards_rho(n)
    if len(factors) != 1:
        raise ValueError("Pollard's Rho failed to find the factors of n.")
    p = factors[0]
    q = n // p

    # Step 2: Compute φ(n)
    phi = (p - 1) * (q - 1)

    # Step 3: Compute private key d
    d = pow(e, -1, phi)  # Modular multiplicative inverse of e mod φ(n)

    # Step 4: Decrypt the ciphertext
    m = pow(c, d, n)  # Modular exponentiation
    return m
