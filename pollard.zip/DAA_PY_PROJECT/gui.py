import tkinter as tk
from tkinter import messagebox, ttk
from performance import measure_performance, compare_algorithms
from algorithms import rsa_decrypt_with_pollards_rho
from utils import is_valid_integer


def factorize_number():
    """Factorize a single number using the selected algorithm and display the results."""
    try:
        number = entry_number.get()
        if not is_valid_integer(number):
            raise ValueError("Invalid input: Please enter an integer greater than 1.")

        n = int(number)
        algorithm = var_algorithm.get()

        # Perform factorization
        time_taken, factors = measure_performance(n, algorithm)
        result_text = f"Factors of {n} using {algorithm}:\n{factors}\n"
        result_text += f"Time taken: {time_taken:.5f} seconds"

        # Update result text
        result_textbox.delete(1.0, tk.END)
        result_textbox.insert(tk.END, result_text)

    except ValueError as e:
        messagebox.showerror("Input Error", str(e))


def compare_algorithms_gui():
    """Run comparison on a list of numbers and display results."""
    try:
        numbers = entry_numbers.get().split(',')
        numbers = [int(n.strip()) for n in numbers if is_valid_integer(n.strip())]

        # Run comparison
        results = compare_algorithms(numbers)
        display_text = "Performance Comparison:\n\n"

        # Format results
        for algo in results:
            display_text += f"{algo}:\n"
            for result in results[algo]:
                display_text += f"  Number: {result['number']}, Time: {result['time']:.5f} sec, Factors: {result['factors']}\n"

        # Update result text
        result_textbox.delete(1.0, tk.END)
        result_textbox.insert(tk.END, display_text)

    except Exception as e:
        messagebox.showerror("Error", f"Error in comparison: {str(e)}")


def rsa_decrypt_gui():
    """Decrypt an RSA ciphertext using Pollard's Rho and display the plaintext message."""
    try:
        # Get inputs
        n = entry_rsa_n.get()
        e = entry_rsa_e.get()
        c = entry_rsa_c.get()

        if not (is_valid_integer(n) and is_valid_integer(e) and is_valid_integer(c)):
            raise ValueError("Invalid input: Please enter integers greater than 1.")

        n, e, c = int(n), int(e), int(c)

        # Perform decryption
        plaintext = rsa_decrypt_with_pollards_rho(n, e, c)
        result_text = f"RSA Decryption Results:\n\nModulus (n): {n}\nExponent (e): {e}\nCiphertext (c): {c}\n"
        result_text += f"Decrypted Message: {plaintext}\n"

        # Update result text
        result_textbox.delete(1.0, tk.END)
        result_textbox.insert(tk.END, result_text)

    except ValueError as e:
        messagebox.showerror("Input Error", str(e))
    except Exception as e:
        messagebox.showerror("Error", f"Error during decryption: {str(e)}")


# Create main window
root = tk.Tk()
root.title("Integer Factorization & RSA Tool")
root.geometry("700x800")
root.resizable(False, False)

# Style configuration
style = ttk.Style()
style.configure("TLabel", font=("Helvetica", 12), padding=5, foreground="white")
style.configure("TButton", font=("Helvetica", 12), padding=5, background="#007BFF", foreground="black", relief="raised")
style.configure("TEntry", font=("Helvetica", 12), fieldbackground="#f7f7f7", relief="solid")
style.configure("TFrame", background="#f0f4f8")

# Title Label
title_label = ttk.Label(root, text="Integer Factorization & RSA Decryption", font=("Helvetica", 16, "bold"), background="#0056b3", foreground="white")
title_label.pack(pady=10)

# Tabs for different functionalities
tabs = ttk.Notebook(root)
tabs.pack(fill="both", expand=True, padx=10, pady=10)

# Factorization Tab
factorization_tab = ttk.Frame(tabs, style="TFrame")
tabs.add(factorization_tab, text="Factorization")

# RSA Tab
rsa_tab = ttk.Frame(tabs, style="TFrame")
tabs.add(rsa_tab, text="RSA Decryption")

# Comparison Tab
comparison_tab = ttk.Frame(tabs, style="TFrame")
tabs.add(comparison_tab, text="Compare Algorithms")

# Factorization Tab Content
ttk.Label(factorization_tab, text="Enter a number to factorize:", background="#f0f4f8", foreground="black").pack(pady=5)
entry_number = ttk.Entry(factorization_tab, width=30)
entry_number.pack()

# Algorithm selection
var_algorithm = tk.StringVar(value="trial_division")
ttk.Label(factorization_tab, text="Choose Algorithm:", background="#f0f4f8", foreground="black").pack(pady=5)
ttk.Radiobutton(factorization_tab, text="Trial Division", variable=var_algorithm, value="trial_division", style="TRadiobutton").pack()
ttk.Radiobutton(factorization_tab, text="Pollard's Rho", variable=var_algorithm, value="pollards_rho", style="TRadiobutton").pack()

# Factorization Button
factorize_button = ttk.Button(factorization_tab, text="Factorize", command=factorize_number)
factorize_button.pack(pady=10)

# RSA Tab Content
ttk.Label(rsa_tab, text="Enter RSA Parameters:", background="#f0f4f8", foreground="black").pack(pady=5)

rsa_frame = ttk.Frame(rsa_tab, style="TFrame")
rsa_frame.pack(pady=10)

ttk.Label(rsa_frame, text="Modulus (n):", background="#f0f4f8", foreground="black").grid(row=0, column=0, sticky="e", padx=5, pady=5)
entry_rsa_n = ttk.Entry(rsa_frame, width=30)
entry_rsa_n.grid(row=0, column=1, padx=5, pady=5)

ttk.Label(rsa_frame, text="Exponent (e):", background="#f0f4f8", foreground="black").grid(row=1, column=0, sticky="e", padx=5, pady=5)
entry_rsa_e = ttk.Entry(rsa_frame, width=30)
entry_rsa_e.grid(row=1, column=1, padx=5, pady=5)

ttk.Label(rsa_frame, text="Ciphertext (c):", background="#f0f4f8", foreground="black").grid(row=2, column=0, sticky="e", padx=5, pady=5)
entry_rsa_c = ttk.Entry(rsa_frame, width=30)
entry_rsa_c.grid(row=2, column=1, padx=5, pady=5)

decrypt_button = ttk.Button(rsa_tab, text="Decrypt", command=rsa_decrypt_gui)
decrypt_button.pack(pady=10)

# Comparison Tab Content
ttk.Label(comparison_tab, text="Enter numbers to compare (comma-separated):", background="#f0f4f8", foreground="black").pack(pady=5)
entry_numbers = ttk.Entry(comparison_tab, width=50)
entry_numbers.pack()

compare_button = ttk.Button(comparison_tab, text="Compare Algorithms", command=compare_algorithms_gui)
compare_button.pack(pady=10)

# Result Textbox
result_textbox = tk.Text(root, height=20, wrap="word", font=("Helvetica", 12), bg="#f7f7f7", fg="black")
result_textbox.pack(fill="both", padx=10, pady=10)

# Start GUI loop
root.mainloop()
