# Integer Factorization Project with GUI

This project focuses on integer factorization using two core algorithms: **Trial Division** and **Pollard's Rho**. It includes a comparison of these algorithms’ performance and provides a GUI for interactive exploration. The project emphasizes understanding the efficiency of factorization methods, relevant for cryptography and number theory applications.

## Project Structure
- **main.py**: Launches the program with options for command-line and GUI interfaces.
- **algorithms.py**: Contains implementations of the Trial Division and Pollard’s Rho algorithms.
- **performance.py**: Includes functions for analyzing the performance of each algorithm.
- **utils.py**: Contains helper functions for the project.
- **gui.py**: Implements a Tkinter-based GUI.
- **data/**: Folder for test data files (if needed).
- **results/**: Folder to store and export algorithm performance results.
- **requirements.txt**: Lists required Python packages.

## Features
### 1. Algorithms
- **Trial Division**: A straightforward, brute-force approach to factorization.
- **Pollard's Rho**: A probabilistic and efficient factorization algorithm.

### 2. Performance Comparison
- Provides time-based performance comparisons between the algorithms for different inputs.
- Results can be saved in JSON format for later analysis.

### 3. GUI
- Factorize any number interactively using the GUI.
- Choose between algorithms, view results, and save performance data.

## Setup and Usage
### Installation
Install the necessary packages:
```bash
pip install -r requirements.txt
