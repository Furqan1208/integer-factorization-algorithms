import time
import json
from algorithms import trial_division, pollards_rho

def measure_performance(n, algorithm):
    """
    Measure the execution time of a factorization algorithm on input n.
    Returns time taken and the factors found.
    """
    start_time = time.time()
    if algorithm == 'trial_division':
        factors = trial_division(n)
    elif algorithm == 'pollards_rho':
        factors = pollards_rho(n)
    else:
        raise ValueError("Unsupported algorithm specified.")
    end_time = time.time()
    return end_time - start_time, factors

def compare_algorithms(n_values):
    """
    Compare Trial Division and Pollard's Rho for a list of integers.
    Returns and saves performance results in JSON format.
    """
    results = {'trial_division': [], 'pollards_rho': []}
    
    for n in n_values:
        td_time, td_factors = measure_performance(n, 'trial_division')
        pr_time, pr_factors = measure_performance(n, 'pollards_rho')
        
        results['trial_division'].append({'number': n, 'time': td_time, 'factors': td_factors})
        results['pollards_rho'].append({'number': n, 'time': pr_time, 'factors': pr_factors})
    
    # Save results to a JSON file for further analysis
    with open('results/performance_results.json', 'w') as f:
        json.dump(results, f, indent=4)
    return results

def load_performance_results(file_path='results/performance_results.json'):
    """Load previously saved performance results from a JSON file."""
    with open(file_path, 'r') as f:
        results = json.load(f)
    return results
