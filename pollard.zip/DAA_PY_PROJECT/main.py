import json
from performance import measure_performance, compare_algorithms
from algorithms import rsa_decrypt_with_pollards_rho

def dynamic_rsa_decryption():
    """
    Dynamically perform RSA decryption by accepting inputs from the user.
    """
    try:
        print("\n--- RSA Decryption Using Pollard's Rho ---")
        
        # Input RSA parameters
        n = int(input("Enter modulus (n): "))
        e = int(input("Enter public key exponent (e): "))
        c = int(input("Enter ciphertext (c): "))
        
        # Perform RSA decryption
        print("Decrypting...")
        m = rsa_decrypt_with_pollards_rho(n, e, c)
        print(f"\nDecrypted message: {m}\n")
        
    except ValueError as ve:
        print(f"Input error: {ve}")
    except Exception as e:
        print(f"An error occurred during decryption: {e}")

def main():
    """
    Main menu to dynamically choose actions:
    1. Factorize a number
    2. Compare algorithms
    3. Perform RSA decryption
    """
    while True:
        print("\n--- Integer Factorization and RSA ---")
        print("1. Factorize a number")
        print("2. Compare algorithms on a set of numbers")
        print("3. Perform RSA decryption")
        print("4. Exit")
        
        choice = input("Enter your choice: ").strip()
        
        if choice == "1":
            n = int(input("Enter the number to factorize: "))
            algorithm = input("Choose algorithm (trial_division/pollards_rho): ").strip()
            time_taken, factors = measure_performance(n, algorithm)
            print(f"\nFactors of {n} using {algorithm}: {factors}")
            print(f"Time taken: {time_taken:.5f} seconds\n")
        
        elif choice == "2":
            nums = input("Enter numbers for comparison (comma-separated): ").strip()
            nums = [int(n.strip()) for n in nums.split(",") if n.strip().isdigit()]
            results = compare_algorithms(nums)
            print("\nPerformance Comparison:")
            for algo, res in results.items():
                print(f"\n{algo}:")
                for r in res:
                    print(f"  Number: {r['number']}, Time: {r['time']:.5f} sec, Factors: {r['factors']}")
        
        elif choice == "3":
            dynamic_rsa_decryption()
        
        elif choice == "4":
            print("Exiting the program. Goodbye!")
            break
        
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
