def gcd(a, b):
    """Compute the Greatest Common Divisor of a and b."""
    while b:
        a, b = b, a % b
    return a

def is_valid_integer(value):
    """
    Check if a given input is a valid integer and greater than 1.
    Used to validate inputs for factorization.
    """
    try:
        n = int(value)
        return n > 1
    except ValueError:
        return False
