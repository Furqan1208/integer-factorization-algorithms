#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <stdexcept>
#include <numeric>

using namespace std;

// Function to calculate the greatest common divisor (GCD)
int gcd(int a, int b) {
    while (b != 0) {
        int temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Trial Division Algorithm
vector<int> trialDivision(int n) {
    vector<int> factors;
    if (n <= 1) return factors;

    // Factor out all 2's
    while (n % 2 == 0) {
        factors.push_back(2);
        n /= 2;
    }

    // Check odd numbers up to sqrt(n)
    for (int i = 3; i <= sqrt(n); i += 2) {
        while (n % i == 0) {
            factors.push_back(i);
            n /= i;
        }
    }

    // If there's a prime factor greater than sqrt(n)
    if (n > 2) factors.push_back(n);

    return factors;
}

// Pollard's Rho Algorithm
int pollardsRho(int n) {
    if (n <= 1) return -1;
    if (n % 2 == 0) return 2;

    srand(time(0));
    int x = rand() % (n - 2) + 2;
    int y = x;
    int c = rand() % (n - 1) + 1;
    int d = 1;

    while (d == 1) {
        x = (x * x + c) % n;
        y = (y * y + c) % n;
        y = (y * y + c) % n;
        d = gcd(abs(x - y), n);
        if (d == n) return pollardsRho(n);
    }
    return d;
}

// RSA Decryption using Pollard's Rho
int rsaDecryptWithPollardsRho(int n, int e, int c) {
    // Step 1: Factorize n using Pollard's Rho
    int p = pollardsRho(n);
    if (p == -1) throw runtime_error("Failed to find a factor of n");
    int q = n / p;

    // Step 2: Compute f(n)
    int phi = (p - 1) * (q - 1);

    // Step 3: Compute the modular inverse of e mod f(n)
    int d = 1;
    while ((d * e) % phi != 1) {
        d++;
    }

    // Step 4: Decrypt the ciphertext
    int m = 1;
    for (int i = 0; i < d; i++) {
        m = (m * c) % n;
    }

    return m;
}

// Measure execution time of factorization
pair<double, vector<int>> measurePerformance(int n, const string& algorithm) {
    auto start = chrono::high_resolution_clock::now();
    vector<int> factors;
    if (algorithm == "trial_division") {
        factors = trialDivision(n);
    } else if (algorithm == "pollards_rho") {
        int factor = pollardsRho(n);
        if (factor != -1) factors.push_back(factor);
    } else {
        throw invalid_argument("Unsupported algorithm specified.");
    }
    auto end = chrono::high_resolution_clock::now();
    chrono::duration<double> elapsed = end - start;

    return {elapsed.count(), factors};
}

int main() {
    cout << "Welcome to the Integer Factorization & RSA Tool\n";
    cout << "Choose an option:\n";
    cout << "1. Factorize a number\n";
    cout << "2. Compare algorithms\n";
    cout << "3. RSA decryption\n";
    cout << "4. Exit\n";

    int choice;
    cin >> choice;

    switch (choice) {
        case 1: {
            cout << "Enter a number to factorize: ";
            int n;
            cin >> n;
            cout << "Choose algorithm (1 for Trial Division, 2 for Pollard's Rho): ";
            int algo_choice;
            cin >> algo_choice;

            string algorithm = (algo_choice == 1) ? "trial_division" : "pollards_rho";
            auto [time_taken, factors] = measurePerformance(n, algorithm);

            cout << "Factors of " << n << " using " << algorithm << ": ";
            for (int f : factors) cout << f << " ";
            cout << "\nTime taken: " << time_taken << " seconds\n";
            break;
        }

        case 2: {
            cout << "Enter numbers to compare (comma-separated): ";
            string input;
            cin.ignore();
            getline(cin, input);

            vector<int> numbers;
            size_t pos = 0;
            while ((pos = input.find(',')) != string::npos) {
                numbers.push_back(stoi(input.substr(0, pos)));
                input.erase(0, pos + 1);
            }
            numbers.push_back(stoi(input));

            cout << "Comparing Trial Division and Pollard's Rho...\n";
            for (int n : numbers) {
                auto [td_time, td_factors] = measurePerformance(n, "trial_division");
                auto [pr_time, pr_factors] = measurePerformance(n, "pollards_rho");

                cout << "Number: " << n << "\n";
                cout << "  Trial Division - Time: " << td_time << " sec, Factors: ";
                for (int f : td_factors) cout << f << " ";
                cout << "\n";

                cout << "  Pollard's Rho - Time: " << pr_time << " sec, Factors: ";
                for (int f : pr_factors) cout << f << " ";
                cout << "\n";
            }
            break;
        }

        case 3: {
            cout << "Enter RSA parameters (n, e, c): ";
            int n, e, c;
            cin >> n >> e >> c;

            try {
                int plaintext = rsaDecryptWithPollardsRho(n, e, c);
                cout << "Decrypted message: " << plaintext << "\n";
            } catch (const runtime_error& err) {
                cerr << "Error: " << err.what() << "\n";
            }
            break;
        }

        case 4:
            cout << "Exiting the program.\n";
            break;

        default:
            cout << "Invalid choice.\n";
    }

    return 0;
}
